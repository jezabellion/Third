import"./client.1d9869b4.js";
