import{S as s,i as t,s as l}from"./client.1d9869b4.js";export default class extends s{constructor(s){super(),t(this,s,null,null,l,{})}}
